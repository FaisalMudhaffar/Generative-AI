"""
evaluate.py
============
Standalone evaluation script for comparing the base model vs. fine-tuned model
on the letter-counting task.

Usage (after training):
    python evaluate.py --adapter ./lora_adapter --num_samples 20

Can also be imported and called from the notebook.
"""

import re
import argparse
import torch
from unsloth import FastLanguageModel
from dataset_utils import ALL_WORDS, build_dataset

# ─────────────────────────────────────────────────────────────────────────────
# System prompt (must match training)
# ─────────────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """\
You are a precise letter-counting assistant. When asked how many times a letter \
appears in a word, you MUST reason step-by-step as follows:

1. Write out each letter of the word with a position number.
2. For each position, state whether it matches the target letter.
3. Keep a running total after each letter.
4. State the final count as a single digit in your <answer> tag.

Always respond in this EXACT format:
<reasoning>
[your step-by-step reasoning here]
</reasoning>
<answer>
[single digit final answer]
</answer>

--- EXAMPLE ---
Question: How many times does the letter 'o' appear in the word 'room'?

<reasoning>
Let me go through each letter of 'room' one by one:
1. r — is 'r' the letter 'o'? No. Running total: 0
2. o — is 'o' the letter 'o'? Yes! Running total: 1
3. o — is 'o' the letter 'o'? Yes! Running total: 2
4. m — is 'm' the letter 'o'? No. Running total: 2
The letter 'o' appears 2 times in 'room'.
</reasoning>
<answer>
2
</answer>
--- END EXAMPLE ---

Now apply this exact procedure to every question you receive.\
"""


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def extract_answer(text: str):
    m = re.search(r"<answer>\s*(\d+)\s*</answer>", text)
    if m:
        return m.group(1).strip()
    m = re.search(r"\b(\d+)\b", text)
    return m.group(1) if m else None


def query(model, tokenizer, system_prompt, user_prompt, max_new_tokens=400):
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user",   "content": user_prompt},
    ]
    text = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    inputs = tokenizer(text, return_tensors="pt").to(model.device)
    FastLanguageModel.for_inference(model)
    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=0.1,
            do_sample=True,
            pad_token_id=tokenizer.eos_token_id,
        )
    return tokenizer.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)


# ─────────────────────────────────────────────────────────────────────────────
# Main evaluation
# ─────────────────────────────────────────────────────────────────────────────

def evaluate(model, tokenizer, num_samples=20, verbose=True):
    """
    Evaluate the model on a sample from the dataset.

    Returns:
        dict with keys: accuracy, correct, total, results
    """
    ds = build_dataset(system_prompt=SYSTEM_PROMPT)
    samples = list(ds)[:num_samples]

    results = []
    for row in samples:
        user_msg = row["prompt"][-1]["content"]
        gt       = row["answer"]

        response  = query(model, tokenizer, SYSTEM_PROMPT, user_msg)
        predicted = extract_answer(response)
        correct   = (predicted == gt)

        results.append({
            "word":      row["word"],
            "letter":    row["letter"],
            "expected":  gt,
            "predicted": predicted,
            "correct":   correct,
        })

        if verbose:
            mark = "✓" if correct else "✗"
            print(f"  {mark} '{row['letter']}' in '{row['word']}': "
                  f"expected={gt}, got={predicted}")

    n_correct = sum(r["correct"] for r in results)
    accuracy  = n_correct / len(results) if results else 0.0

    print(f"\nAccuracy: {n_correct}/{len(results)} = {accuracy*100:.1f}%")
    return {"accuracy": accuracy, "correct": n_correct, "total": len(results), "results": results}


def compare_old_new(model, tokenizer, user_question, system_prompt=SYSTEM_PROMPT):
    """Print OLD (LoRA disabled) vs NEW (LoRA enabled) responses side by side."""
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user",   "content": user_question},
    ]
    text   = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(text, return_tensors="pt").to(model.device)
    gen_kw = dict(max_new_tokens=512, temperature=0.1, do_sample=True,
                  pad_token_id=tokenizer.eos_token_id)

    FastLanguageModel.for_inference(model)

    model.disable_adapters()
    with torch.no_grad():
        out_old = model.generate(**inputs, **gen_kw)
    old_text = tokenizer.decode(out_old[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)

    model.enable_adapters()
    with torch.no_grad():
        out_new = model.generate(**inputs, **gen_kw)
    new_text = tokenizer.decode(out_new[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)

    sep = "=" * 70
    print(f"\n{sep}\nQUESTION: {user_question}\n{sep}")
    print("\n── OLD MODEL (base, LoRA disabled) ──────────────────────────")
    print(old_text)
    print("\n── NEW MODEL (fine-tuned, LoRA enabled) ─────────────────────")
    print(new_text)
    print(sep)

    return old_text, new_text


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry-point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate fine-tuned letter-counting model")
    parser.add_argument("--adapter",     default="./lora_adapter",        help="Path to saved LoRA adapter")
    parser.add_argument("--base_model",  default="Qwen/Qwen2.5-3B-Instruct")
    parser.add_argument("--num_samples", type=int, default=20)
    parser.add_argument("--no_compare",  action="store_true")
    args = parser.parse_args()

    print(f"Loading model: {args.base_model}")
    print(f"Loading adapter: {args.adapter}")

    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=args.base_model,
        max_seq_length=1024,
        load_in_4bit=True,
    )
    model.load_adapter(args.adapter)

    print(f"\nEvaluating on {args.num_samples} samples...")
    evaluate(model, tokenizer, num_samples=args.num_samples)

    if not args.no_compare:
        compare_old_new(
            model, tokenizer,
            "How many times does the letter 'a' appear in the word 'banana'?"
        )
        # Catastrophic forgetting check
        compare_old_new(
            model, tokenizer,
            "What is the capital of the Philippines?",
            system_prompt="You are a helpful assistant. Answer concisely.",
        )
