"""
reward_functions.py
====================
Standalone reward function module for the GRPO letter-counting project.

These functions are imported by the main notebook but can also be tested
independently by running:
    python reward_functions.py

Each function follows the GRPOTrainer signature:
    func(prompts, completions, **dataset_columns) -> List[float]
"""

import re
from typing import List, Optional


# ─────────────────────────────────────────────────────────────────────────────
# Helper
# ─────────────────────────────────────────────────────────────────────────────

def _get_text(completion) -> str:
    """Extract raw text from a completion object (list-of-dicts or plain str)."""
    if isinstance(completion, list):
        return completion[0].get("content", "")
    return str(completion)


def _extract_reasoning(text: str) -> Optional[str]:
    """Return the content inside <reasoning>...</reasoning>, or None."""
    m = re.search(r"<reasoning>(.*?)</reasoning>", text, re.DOTALL)
    return m.group(1) if m else None


def _extract_answer(text: str) -> Optional[str]:
    """Return the digit inside <answer>...</answer>, or None."""
    m = re.search(r"<answer>\s*(\d+)\s*</answer>", text)
    return m.group(1).strip() if m else None


# ─────────────────────────────────────────────────────────────────────────────
# Reward Function 1: Numbering
# ─────────────────────────────────────────────────────────────────────────────

def numbering_reward_func(
    prompts,
    completions,
    word: List[str],
    **kwargs,
) -> List[float]:
    """
    Reward the model for numbering each letter step in order (1, 2, 3, ...).

    Scoring per completion:
        +0.5  for each in-order number
        -0.5  for each out-of-order number
        -1.0  for each number beyond the word's actual length

    Args:
        prompts:     list of prompt inputs (required by GRPOTrainer, unused here)
        completions: list of model completions
        word:        list of target words, one per completion

    Returns:
        List of float rewards.
    """
    rewards = []

    for completion, w in zip(completions, word):
        text = _get_text(completion)
        word_length = len(w)
        reward = 0.0

        reasoning = _extract_reasoning(text)
        if reasoning:
            numbers_found = [
                int(n)
                for n in re.findall(r"^\s*(\d+)[.)]\s", reasoning, re.MULTILINE)
            ]
            expected = 1
            for num in numbers_found:
                if num > word_length:
                    reward -= 1.0   # hallucinated step beyond word length
                elif num == expected:
                    reward += 0.5   # correct in-order step
                    expected += 1
                else:
                    reward -= 0.5   # out-of-order step

        rewards.append(reward)

    return rewards


# ─────────────────────────────────────────────────────────────────────────────
# Reward Function 2: Spelling
# ─────────────────────────────────────────────────────────────────────────────

def spelling_reward_func(
    prompts,
    completions,
    word: List[str],
    **kwargs,
) -> List[float]:
    """
    Reward the model for correctly spelling out the word letter-by-letter
    in its numbered reasoning steps.

    Scoring per completion:
        +2.0  exact correct spelling (all letters match, correct length)
        -1.0  per extra letter beyond the word length
        -0.5  per missing letter below the word length
        -0.5  per mismatched letter in the overlap region

    Args:
        prompts:     list of prompt inputs (unused)
        completions: list of model completions
        word:        list of target words

    Returns:
        List of float rewards.
    """
    rewards = []

    for completion, w in zip(completions, word):
        text = _get_text(completion)
        w_letters = list(w.lower())

        reasoning = _extract_reasoning(text)
        if not reasoning:
            rewards.append(-1.0)
            continue

        # Extract single letter after "N. " or "N) "
        extracted = [
            l.lower()
            for l in re.findall(r"^\s*\d+[.)]\s+([a-zA-Z])", reasoning, re.MULTILINE)
        ]

        if extracted == w_letters:
            rewards.append(2.0)
            continue

        reward = 0.0
        diff = len(extracted) - len(w_letters)
        if diff > 0:
            reward -= 1.0 * diff          # extra letters
        elif diff < 0:
            reward -= 0.5 * abs(diff)     # missing letters

        overlap = min(len(extracted), len(w_letters))
        mismatches = sum(
            1 for a, b in zip(extracted[:overlap], w_letters[:overlap]) if a != b
        )
        reward -= 0.5 * mismatches

        rewards.append(reward)

    return rewards


# ─────────────────────────────────────────────────────────────────────────────
# Reward Function 3: Counting
# ─────────────────────────────────────────────────────────────────────────────

def counting_reward_func(
    prompts,
    completions,
    word: List[str],
    letter: List[str],
    **kwargs,
) -> List[float]:
    """
    Reward the model for maintaining an accurate running total at each step.

    Extracts lines of the form:
        "N. <letter> — ... Running total: <number>"
    and compares the stated total to the actual cumulative count.

    Scoring per step:
        +1.0  running total is correct
        -1.0  running total is incorrect

    Final reward is the mean over all steps, giving a value in [-1.0, +1.0].

    Args:
        prompts:     list of prompt inputs (unused)
        completions: list of model completions
        word:        list of target words
        letter:      list of target letters (one per completion)

    Returns:
        List of float rewards in [-1.0, +1.0].
    """
    rewards = []

    for completion, w, l in zip(completions, word, letter):
        text = _get_text(completion)
        w_lower = w.lower()
        l_lower = l.lower()

        reasoning = _extract_reasoning(text)
        if not reasoning:
            rewards.append(-1.0)
            continue

        # Match: "N. <letter> ... Running total: <number>"
        steps = re.findall(
            r"^\s*\d+[.)]\s+([a-zA-Z]).*?(?:[Rr]unning\s+[Tt]otal|total)[:\s]+?(\d+)",
            reasoning,
            re.MULTILINE,
        )

        if not steps:
            rewards.append(-1.0)
            continue

        step_scores = []
        running_total = 0

        for idx, (step_letter, stated_total) in enumerate(steps):
            actual_letter = w_lower[idx] if idx < len(w_lower) else step_letter.lower()
            if actual_letter == l_lower:
                running_total += 1

            step_scores.append(1.0 if int(stated_total) == running_total else -1.0)

        rewards.append(sum(step_scores) / len(step_scores))

    return rewards


# ─────────────────────────────────────────────────────────────────────────────
# Reward Function 4: Format
# ─────────────────────────────────────────────────────────────────────────────

def format_reward_func(
    prompts,
    completions,
    **kwargs,
) -> List[float]:
    """
    Reward the model for using the correct structured output format.

    Scoring per completion:
        +0.5  correct <reasoning>...</reasoning><answer>...</answer> format
        +0.5  the <answer> tag contains a digit

    Maximum reward: +1.0

    Args:
        prompts:     list of prompt inputs (unused)
        completions: list of model completions

    Returns:
        List of float rewards in [0.0, +1.0].
    """
    rewards = []

    for completion in completions:
        text = _get_text(completion)
        reward = 0.0

        has_reasoning = bool(re.search(r"<reasoning>.*?</reasoning>", text, re.DOTALL))
        has_answer    = bool(re.search(r"<answer>.*?</answer>",       text, re.DOTALL))

        if has_reasoning and has_answer:
            reward += 0.5

        if re.search(r"<answer>\s*\d+\s*</answer>", text):
            reward += 0.5

        rewards.append(reward)

    return rewards


# ─────────────────────────────────────────────────────────────────────────────
# Reward Function 5: Correct Answer
# ─────────────────────────────────────────────────────────────────────────────

def correct_answer_reward_func(
    prompts,
    completions,
    answer: List[str],
    **kwargs,
) -> List[float]:
    """
    Provide a strong signal for whether the final answer is correct.

    Extracts the number from <answer>...</answer> and compares to ground truth.
    Falls back to the first standalone digit in the completion if no tag found.

    Scoring per completion:
        +2.0  predicted answer matches ground truth
        -1.0  predicted answer does not match ground truth

    Args:
        prompts:     list of prompt inputs (unused)
        completions: list of model completions
        answer:      list of ground-truth answer strings (e.g., ["2", "3"])

    Returns:
        List of float rewards in {-1.0, +2.0}.
    """
    rewards = []

    for completion, gt in zip(completions, answer):
        text = _get_text(completion)

        predicted = _extract_answer(text)
        if predicted is None:
            # Last resort: grab first digit
            m = re.search(r"\b(\d+)\b", text)
            predicted = m.group(1) if m else "-1"

        rewards.append(2.0 if predicted == str(gt) else -1.0)

    return rewards


# ─────────────────────────────────────────────────────────────────────────────
# Self-test
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    PERFECT = [[{"content": """
<reasoning>
1. r — is 'r' the letter 'o'? No. Running total: 0
2. o — is 'o' the letter 'o'? Yes! Running total: 1
3. o — is 'o' the letter 'o'? Yes! Running total: 2
4. m — is 'm' the letter 'o'? No. Running total: 2
The letter 'o' appears 2 times in 'room'.
</reasoning>
<answer>2</answer>"""}]]

    TERRIBLE = [[{"content": "The answer is probably seven I think."}]]

    funcs = [
        ("format",         lambda c, w, l: format_reward_func(None, c)),
        ("numbering",      lambda c, w, l: numbering_reward_func(None, c, w)),
        ("spelling",       lambda c, w, l: spelling_reward_func(None, c, w)),
        ("counting",       lambda c, w, l: counting_reward_func(None, c, w, l)),
        ("correct_answer", lambda c, w, l: correct_answer_reward_func(None, c, ["2"])),
    ]

    print(f"\n{'Reward Function':<22} {'Perfect':>10} {'Terrible':>10} {'Pass?':>8}")
    print("-" * 54)
    all_ok = True
    for name, fn in funcs:
        rp = fn(PERFECT,  ["room"], ["o"])[0]
        rt = fn(TERRIBLE, ["room"], ["o"])[0]
        ok = rp > rt
        all_ok = all_ok and ok
        print(f"{name:<22} {rp:>10.2f} {rt:>10.2f} {'✓' if ok else '✗':>8}")

    print()
    if all_ok:
        print("✓ All reward functions passed self-test!")
    else:
        print("✗ Some reward functions failed — check the logic above.")
