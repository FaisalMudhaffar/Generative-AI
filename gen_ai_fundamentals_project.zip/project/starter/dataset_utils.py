"""
dataset_utils.py
=================
Utilities for building the letter-counting dataset used in GRPO training.

Usage:
    from dataset_utils import ALL_WORDS, generate_records, build_dataset
    ds = build_dataset(ALL_WORDS, system_prompt=MY_SYSTEM_PROMPT)
"""

import random
from typing import List, Dict, Optional
from datasets import Dataset


# ─────────────────────────────────────────────────────────────────────────────
# Word list
# ─────────────────────────────────────────────────────────────────────────────

ALL_WORDS: List[str] = [
    # Fruits & nature
    "apple", "banana", "cherry", "dragon", "elephant",
    "flower", "garden", "jungle", "rainbow", "thunder",
    # Common nouns
    "freedom", "gravity", "harmony", "island", "kitchen",
    "lantern", "monster", "network", "optical", "pattern",
    "quantum", "shelter", "umbrella", "village", "whisper",
    "yellow", "zebra", "balance", "captain", "diamond",
    # Academic / technical
    "energy", "fantasy", "general", "history", "integer",
    "journey", "kingdom", "library", "mystery", "natural",
    "opinion", "process", "quality", "reality", "science",
    "testing", "uniform", "victory", "warning", "example",
    "program", "student", "teacher", "problem", "answer",
    "matrix", "vector", "factor", "method", "system",
    # Short everyday words
    "ribbon", "silver", "temple", "winter", "zipper",
    "mirror", "pillow", "hammer", "xylophone", "amazing",
]


# ─────────────────────────────────────────────────────────────────────────────
# Record generation
# ─────────────────────────────────────────────────────────────────────────────

def generate_records(
    words: List[str],
    system_prompt: str,
    seed: int = 42,
) -> List[Dict]:
    """
    Generate one training record per (word, unique_letter) pair.

    Each record contains:
        - "prompt":  chat-format messages list (system + user)
        - "word":    the target word
        - "letter":  the target letter
        - "answer":  ground-truth count (string)

    Args:
        words:         list of words to use
        system_prompt: system prompt string
        seed:          random seed for shuffling

    Returns:
        Shuffled list of record dicts.
    """
    records = []
    for word in words:
        for letter in set(word.lower()):
            count = word.lower().count(letter)
            user_msg = (
                f"How many times does the letter '{letter}' "
                f"appear in the word '{word}'?"
            )
            records.append({
                "prompt": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user",   "content": user_msg},
                ],
                "word":   word,
                "letter": letter,
                "answer": str(count),
            })

    rng = random.Random(seed)
    rng.shuffle(records)
    return records


def build_dataset(
    words: Optional[List[str]] = None,
    system_prompt: str = "",
    seed: int = 42,
) -> Dataset:
    """
    Convenience wrapper: generate records and return a HuggingFace Dataset.

    Args:
        words:         word list (defaults to ALL_WORDS)
        system_prompt: system prompt to embed in every record
        seed:          random seed

    Returns:
        HuggingFace Dataset with columns: prompt, word, letter, answer
    """
    if words is None:
        words = ALL_WORDS
    records = generate_records(words, system_prompt, seed=seed)
    return Dataset.from_list(records)


# ─────────────────────────────────────────────────────────────────────────────
# Self-test
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    ds = build_dataset(system_prompt="You are a helpful assistant.")
    print(f"Dataset size: {len(ds)}")
    print(f"Columns: {ds.column_names}")
    sample = ds[0]
    print(f"\nSample:")
    print(f"  word:   {sample['word']}")
    print(f"  letter: {sample['letter']}")
    print(f"  answer: {sample['answer']}")
    print(f"  prompt (user): {sample['prompt'][-1]['content']}")

    # Verify counts
    errors = 0
    for row in ds:
        expected = str(row["word"].lower().count(row["letter"]))
        if row["answer"] != expected:
            print(f"  ERROR: {row['word']}, '{row['letter']}' → got {row['answer']}, expected {expected}")
            errors += 1
    print(f"\n✓ All {len(ds)} records have correct ground-truth answers." if errors == 0
          else f"✗ {errors} records have incorrect answers!")
