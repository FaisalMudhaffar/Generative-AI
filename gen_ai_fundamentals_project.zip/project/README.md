# Gen AI Fundamentals: Teaching LLMs to Reason with GRPO

## Project: Reasoning Engine — Letter Counting via RL Fine-Tuning

### Overview

This project teaches a `Qwen2.5-3B-Instruct` model to perform **reliable step-by-step letter counting** using **GRPO (Group Relative Policy Optimization)** reinforcement learning and **LoRA (Low-Rank Adaptation)**.

> **The Problem:** LLMs confidently give wrong answers to simple counting tasks.  
> **The Solution:** RL fine-tuning with structured reward functions that reward *correct reasoning*, not just correct answers.

---

### Project Structure

```
project/
├── README.md                                    ← This file
├── requirements.txt                             ← Pinned Python dependencies
└── starter/
    └── gen_ai_fundamentals_project_starter.ipynb  ← Main notebook (submit this)
```

---

### Quick Start

#### Option 1: Vocareum Workspace (Recommended)
1. Open the Vocareum workspace from the Cloud Resources tab
2. Navigate to `project/starter/`
3. Open `gen_ai_fundamentals_project_starter.ipynb`
4. Select the **Python (venv2)** kernel
5. Run all cells top to bottom

#### Option 2: Google Colab
1. Upload `project/starter/gen_ai_fundamentals_project_starter.ipynb` to Colab
2. Enable T4 GPU: `Runtime → Change runtime type → T4 GPU`
3. Run the pip install cell at the top

#### Option 3: Local Setup
```bash
# 1. Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# 2. Install Python 3.12.3 and dependencies
cd project/
uv python pin 3.12.3
uv init
uv sync
uv add ipykernel pip
uv pip install -r requirements.txt

# 3. Launch Jupyter
jupyter lab
```

---

### What the Notebook Does

| Phase | Description |
|-------|-------------|
| **1 — Setup** | Load `Qwen2.5-3B-Instruct` with 4-bit quantization + LoRA adapters |
| **2 — Baseline** | Show the model fails without prompting; improve with CoT + few-shot |
| **3 — Dataset** | Generate (word, letter, count) triples formatted as chat conversations |
| **4 — Rewards** | Implement 5 reward functions covering format, numbering, spelling, counting, correctness |
| **5 — Training** | Run GRPO: 5-step quick check + 80-step full training run |
| **6 — Results** | Compare old vs. new model; verify no catastrophic forgetting |

---

### Key Technologies

| Technology | Role |
|-----------|------|
| **LoRA** | Parameter-efficient fine-tuning — trains ~30M of 3B params |
| **Unsloth** | 2× faster training, 60% less VRAM via custom CUDA kernels |
| **vLLM** | High-speed inference via PagedAttention during GRPO rollouts |
| **GRPO** | RL algorithm: generate → reward → optimize policy |

---

### LoRA Configuration

```python
lora_rank       = 64          # Balanced expressiveness vs. T4 VRAM
lora_alpha      = 64          # Scale factor (= rank is standard)
target_modules  = [
    "q_proj", "k_proj",       # Attention: what to attend to
    "v_proj", "o_proj",       # Attention: how to combine
    "gate_proj", "up_proj",   # MLP: feature transformation
    "down_proj",              # MLP: projection back
]
```

---

### Reward Functions

| Function | Behavior |
|----------|----------|
| `format_reward_func` | +1.0 for correct XML format + digit answer |
| `numbering_reward_func` | +0.5 in-order / −0.5 out-of-order / −1.0 hallucinated steps |
| `spelling_reward_func` | +2.0 perfect / penalties for extra/missing/wrong letters |
| `counting_reward_func` | ±1.0 per step normalized to [−1, 1] |
| `correct_answer_reward_func` | +2.0 correct / −1.0 wrong |

---

### Hardware Requirements

- **GPU:** NVIDIA T4 (16 GB VRAM) or better
- **RAM:** 16 GB system RAM recommended
- **Disk:** ~15 GB free (model weights + adapter)
- **Time:** ~30–60 minutes for the full training run

---

### Expected Outputs

After completing the notebook you should observe:

1. **Training logs** showing `reward` and `rewards/correct_answer_reward_func/mean` trending upward
2. **OLD model** (no LoRA): gives wrong or unstructured answers
3. **NEW model** (LoRA fine-tuned): reasons step-by-step and gets the correct count
4. **General knowledge preserved**: both models correctly answer "What is the capital of the Philippines?"

---

### Submission Checklist

- [ ] All TODO sections completed
- [ ] `lora_rank` and `target_modules` choices explained in comments
- [ ] All 5 reward functions implemented with validation passing
- [ ] Quick training run (5 steps) output visible
- [ ] Full training run (80+ steps) output visible with upward reward trend
- [ ] Training reward plot generated
- [ ] OLD vs. NEW model comparison output visible
- [ ] Catastrophic forgetting check output visible

---

### Troubleshooting

**CUDA out of memory:**
- Reduce `per_device_train_batch_size` from 16 to 8
- Reduce `vllm_gpu_memory_utilization` from 0.3 to 0.2
- Ensure no other GPU processes are running (`nvidia-smi`)

**vLLM not available:**
- Set `use_vllm=False` in GRPOConfig (slower but works)

**Kernel not listed:**
- Click the refresh icon in the kernel selection menu
- Activate the venv: `source /voc/data/venv2/bin/activate`
